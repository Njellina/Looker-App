package com.example.projectapp;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.content.Intent;

public class RegisterActivity extends AppCompatActivity {

    private ImageButton applicant;
    private ImageButton company;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registeractivity);

        applicant = (ImageButton) findViewById(R.id.applicant);
        company = (ImageButton) findViewById(R.id.company);

        applicant.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(RegisterActivity.this, RegisterApplicant.class));
            }
        });

        company.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(RegisterActivity.this, RegisterCompany.class));
            }
        });

    }
}
