package com.example.projectapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.Objects;

public class DatabaseJava extends SQLiteOpenHelper{
    Context context;
    public static final String DBNAME = "Users.db";
    public static final String Table_Applicant = "Applicant";
    public static final String Table_Company = "Company";
    public static final String EMAIL = "email";
    public static final String USERNAME = "name";
    public static final String PASSWORD = "password";
    public static final String PHONE = "phone";
    public static final String ADDRESS = "address";

    public DatabaseJava(Context context) {
        super(context, "Company.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table Company(ID INT primary key, name TEXT, email TEXT, password TEXT, phone TEXT, address TEXT)");
        MyDB.execSQL("create Table Applicant(ID INT primary key, name TEXT, email TEXT, password TEXT, phone TEXT, address TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists Company");
        MyDB.execSQL("drop Table if exists Applicant");
    }

    public Boolean insertDataCompany(String name, String email, String password, String phone, String address){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("phone", phone);
        contentValues.put("address", address);
        long result = MyDB.insert("Company", null, contentValues);
        if (result == -1) return false;
        else return true;
    }

    public Boolean insertDataApplicant(String name, String email, String password, String phone, String address){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("phone", phone);
        contentValues.put("address", address);
        long result = MyDB.insert("Applicant", null, contentValues);
        if (result == -1) return false;
        else return true;
    }

    public Boolean checkEmailCompany(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from Company where email = ?", new String[] {email});
        if (cursor.getCount() > 0) return true;
        else return false;
    }

    public Boolean checkLoginCompany(String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from Company where email = ? and password = ?", new String[] {email, password});
        if (cursor.getCount() > 0) return true;
        else return false;
    }

    public Boolean checkEmailApplicant(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from Company where email = ?", new String[] {email});
        if (cursor.getCount() > 0) return true;
        else return false;
    }

    public Boolean checkLoginApplicant(String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from Applicant where email = ? and password = ?", new String[] {email, password});
        if (cursor.getCount() > 0) return true;
        else return false;
    }

    public Boolean checkAdmin(String AdminID, String AdminCode){
        SQLiteDatabase db = this.getWritableDatabase();
        if (Objects.equals(AdminID, "4dmin") && Objects.equals(AdminCode, "admin123")){
            return true;
        }
        else return false;
    }

    public Cursor DataApplicant(){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Applicant", null);
        return  cursor;
    }

    public Cursor DataCompany(){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Company", null);
        return  cursor;
    }

    public void deleteAllApplicant(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from Applicant");
    }

    public void deleteAllCompany(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from Company");
    }

    void deleteDataApplicant(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(Table_Applicant, "email = ?", new String[] {email});

        if (result == -1){
            Toast.makeText(context, "Error!", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Delete Successful!", Toast.LENGTH_SHORT).show();
        }
    }

    void deleteDataCompany(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(Table_Company, "email = ?", new String[] {email});

        if (result == -1){
            Toast.makeText(context, "Error!", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Delete Successful!", Toast.LENGTH_SHORT).show();
        }
    }

    public Cursor searchApplicant(String email){
        SQLiteDatabase db = this.getWritableDatabase();

        String[] columns = new String[] {USERNAME, EMAIL, PASSWORD, PHONE, ADDRESS};
        Cursor cursor = db.query(Table_Applicant, columns, "email = ?", new String[] {email}, null, null, null, null);
        return cursor;
    }

    public Cursor searchCompany(String email){
        SQLiteDatabase db = this.getWritableDatabase();

        String[] columns = new String[] {USERNAME, EMAIL, PASSWORD, PHONE, ADDRESS};
        Cursor cursor = db.query(Table_Company, columns, "email = ?", new String[] {email}, null, null, null, null);
        return cursor;
    }


}
