package com.example.projectapp;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.content.Intent;

public class LoginActivity extends AppCompatActivity {
    private ImageButton applicant;
    private ImageButton company;
    private ImageButton admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginactivity);

//        ImageButton regis = findViewById(R.id.regis);
        applicant = (ImageButton) findViewById(R.id.applicant);
        company = (ImageButton) findViewById(R.id.company);
        admin = (ImageButton) findViewById(R.id.admin);

        applicant.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(LoginActivity.this, LoginApplicant.class));
            }
        });

        company.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(LoginActivity.this, LoginCompany.class));
            }
        });

        admin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(LoginActivity.this, LoginAdmin.class));
            }
        });
    }
}